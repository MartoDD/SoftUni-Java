package softuni.exam.util;

public enum Paths {
    ;
    public static final String PATH_OF_MECHANICS = "src/main/resources/files/json/mechanics.json";
    public static final String PATH_OF_PARTS = "src/main/resources/files/json/parts.json";
    public static final String PATH_OF_CARS = "src/main/resources/files/xml/cars.xml";
    public static final String PATH_OF_TASKS = "src/main/resources/files/xml/tasks.xml";
}
