package softuni.exam.util;

public interface ValidationTool {

    <E> boolean isValid(E entity);

}
