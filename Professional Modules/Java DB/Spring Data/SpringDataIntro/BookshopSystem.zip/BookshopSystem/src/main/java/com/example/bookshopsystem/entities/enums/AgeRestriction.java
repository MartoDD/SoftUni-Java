package com.example.bookshopsystem.entities.enums;

public enum AgeRestriction {

    MINOR, TEEN, ADULT
}
