package com.example.bookshopsystem.entities.enums;

public enum EditionTypes {

    NORMAL, PROMO, GOLD
}
